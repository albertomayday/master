"""
Campaign Interfaces Layer - Contratos y Abstracciones
"""