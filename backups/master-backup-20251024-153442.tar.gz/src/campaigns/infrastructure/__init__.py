"""
Campaign Infrastructure Layer - Implementaciones Externas
"""