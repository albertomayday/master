"""
Campaign Domain Layer - Entidades y Lógica de Negocio
"""