"""
Campaign Application Layer - Casos de Uso y Servicios de Aplicación
"""